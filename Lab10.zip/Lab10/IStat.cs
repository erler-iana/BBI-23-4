﻿using System;
using System.Collections.Generic;

namespace Lab10
{
    interface IStatistic
    {
        int Max();
        int Min();
        double Avg();
        double Med();
    }
}
