![UML](https://github.com/TigranMachkalyan/BBI-23-6/blob/main/Lab10/UML%20Classes%20Diagram.png)
